const Color = {
    primary: '#0CB0D3',
    secondry: '#5FD9F3',
    white: '#ffffff'
}

export default Color;