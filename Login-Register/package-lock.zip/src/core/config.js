// Replace with your own firebase config!
import * as firebase from 'firebase';
export const firebaseConfig = {
  apiKey: "AIzaSyDXR-K8Ix7tC4MeWox_mb_n5OLO0SAAP_o",
  authDomain: "selfcare-b9138.firebaseapp.com",
  databaseURL: "https://selfcare-b9138.firebaseio.com",
  projectId: "selfcare-b9138",
  storageBucket: "selfcare-b9138.appspot.com",
  messagingSenderId: "1060599616531",
  appId: "1:1060599616531:web:4198e14795127b76391be6",
  measurementId: "G-5QN4RHVH3L"
};

//const rootRef = firebase.database().ref();
//export const tasksRef = rootRef.child('gratitudeList');
//export const timeRef = firebase.database.ServerValue.TIMESTAMP;
