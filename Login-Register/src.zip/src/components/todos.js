import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ListItem } from 'react-native-elements';
import Color from './../constraints/color';

export default class Todos extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        const list = [
            {
                when:'10:30 AM',
                name: 'Meet Amy Farha',
                icon: 'done-all',
                subtitle: 'Send ammy farha a google meet link and fix agenda for next meeting'
            },
            {
                when:'11:45 AM',
                name: 'Create a report for Chris Jackson',
                icon: 'timer',
                subtitle: 'Chris needs a report to be created so that he can pitch new investor.'
            },
        ];
        return (
            <View style={styles.container}>
                <Text style={styles.dateTitle}>ToDo on : {this.props.date}</Text>
                <View>
                    {
                        list.map((l, i) => (
                            <ListItem
                                key={i}
                                leftIcon={{name:l.icon}}
                                title={l.name}
                                rightSubtitle={l.when}
                                subtitle={l.subtitle}
                                bottomDivider
                                checkBox={true}
                            />
                        ))
                    }
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        // flex: 1,
        backgroundColor: Color.white,
        // width: '100%',
        padding: 12,
        // alignItems: 'center',
        // justifyContent: 'flex-start'
    },
    dateTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Color.primary,
        padding: 5,
        width: '100%',
        textAlign: 'center'
    }
});